<!-- Header -->
<?php
$title = "Contact Us";
include 'include/header.php'; ?>

<!-- banner section start -->
<section class="banner">
    <div class="container">
        <div>
            <p>Eve 2 Down botique</p>
            <h3 class="headings-all">Contact us</h3>
        </div>
    </div>
</section>
<!-- banner section end -->

<!-- form section start -->
<section class="section-2 contactus">
    <div class="container">
        <div class="row justify-content-center align-item-center">
            <div class="col-12 col-lg-10">
                <div class="sections contactus mainform">
                    <div class="row">
                        <div class="col-12">
                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <div class="formHeading">
                                    <h4>We would <span>love</span> to <span>hear</span> from you</h4>
                                    <p>Fill out the form bellow and we will get back to you as soon a possible!</p>
                                    <div class="twoInput">
                                        <input type="text" name="name" placeholder="Name">
                                        <input type="number" name="phone" placeholder="Phone Number">
                                    </div>
                                    <input type="email" name="email" placeholder="Email Address">
                                    <input type="text" name="subject" placeholder="Subject">
                                    <input type="text" name="message" placeholder="Message">
                                   <input type="submit" value="Submit" class="subBtn">
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- touch -->
<section class="section-3 getInTouch">
    <div class="container">
        <div class="row">

            <div class="col-12 col-lg-6">
                <h4>Get in <span>Touch</span></h4>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officia soluta quidem nam obcaecati non molestias provident ea et sequi.</p>
            </div>

        </div>
        <div class="touch">
            <div class="row">
                <div class="col-12 col-lg-5 ">
                    <div class="content callUs">
                        <a href="#">
                            <i class="fa-solid fa-phone"></i>
                            <span>Call Us</span>
                            <p>+000-00-0000</p>
                        </a>
                    </div>
                </div>
                <div class="col-12 col-lg-5">
                    <div class="content email">
                        <a href="#">
                            <i class="fa-solid fa-envelope"></i>
                            <span>Email Us</span>
                            <p>example@gmail.com</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<?php include 'include/footer.php'; ?>