</body>
<?php include 'include/js.php'; ?>

<!-- footer -->
<footer class="container-fluid">
    <div class="row">
        <div class="col-10 col-lg-6">
    <h4>Newsletter</h4>
    <p>Recieveour weekly newsletter. For dietary content, fashion insider and the<br>best offer.</p>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <input type="email" name="" value="" placeholder="Email address"/>
        <input type="submit" name="" value="Join" />
    </form>
    <p class="icons">
        <a href="#"><i class="fa-brands fa-facebook-f"></i> </a>
        <a href="#"><i class="fa-brands fa-twitter"></i> </a>
        <a href="#"><i class="fa-brands fa-pinterest"></i> </a>
        <a href="#"><i class="fa-brands fa-vimeo-v"></i> </a>
        <a href="#"><i class="fa-brands fa-instagram"></i> </a>
    </p>
    <p class="terms"> <a href="#">USD</a> &nbsp;&nbsp;|&nbsp;&nbsp; <a href="#">Privacy Policy </a>&nbsp;&nbsp;|&nbsp;&nbsp; <a href="#">Terms of Uses </a>&nbsp;&nbsp;|&nbsp;&nbsp; <a href="#">FAQs</a></p>
    </div>
    </div>
</footer>

<p class="copyright">copyright &copy; 2022 Eve2DownBoutique. All right reserved.</p>
</html>