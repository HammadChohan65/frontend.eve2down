<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include 'include/css.php'; ?>
    <title><?php echo isset($title) ? $title : 'Home';  ?></title>

    <style>
        .sub-header {
            text-align: center;
            text-transform: uppercase;
        }

        .sub-header .row {
            background: #9e6a5a;
            color: #fff;
            padding: 5px 0 5px 0;
            font-weight: 100;

        }

        .sub-header .row p {
            margin-bottom: 0;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        .sub-header .row p a {
            color: #fff;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        nav .row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 15px auto 15px auto;
        }

        nav ul {
            display: flex;
            justify-content: space-between;
            gap: 1.3rem;
        }

        nav ul li {
            text-transform: uppercase;
            font-size: 1rem;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        nav ul li:hover {
            color: #9e6a5a;
        }

        nav ul li a i {
            margin-right: 10px;
            color: #9e6a5a;
            font-size: 1rem;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        nav h3 {
            margin-bottom: 1px;
            font-size: 1.8rem;
            font-weight: 300;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        nav p {
            margin-bottom: 1px;
            letter-spacing: 8px;
            font-size: 1.1rem;
            line-height: 18px;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        nav #brand-name {
            text-align: center;
        }

        nav .search {
            justify-content: flex-end;
        }

        nav .search li {

            font-family: 'LeMondeLivre Demi Small Caps';
            margin-right: 1.5rem;
        }

        nav .search li a,
        nav ul li a {
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        nav #brand-name span {
            font-weight: 500;
            font-size: 2rem;
        }

        #brand-name {
            text-transform: capitalize;
        }

        .banner {
            width: 100%;
            height: 57vh;
            background: url('images/banner.png');
            position: relative;
            background-position: center;
            background-size: cover;
        }

        .banner .container div {
            position: absolute;
            top: 40%;
            left: 15%;
        }

        .banner .container div p {
            font-size: 2rem;
            color: #69301e;
            margin-bottom: 0;
            line-height: 39px;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        .viewDetails a {
            color: #9e6a5a;
            font-weight: 500;
            text-decoration: underline;
        }

        .banner .container div h3 {
            font-size: 5.5rem;
            color: #fff;
            font-family: 'Annabelle';
            text-transform: capitalize;
            font-weight: 500;
            text-shadow: 1px 4px 2px #69301e;
        }

        .brand-img {
            height: 100%;
            width: 100%;
            background: linear-gradient(to top, rgba(105, 48, 30, 0.6), transparent), url(images/brand.png);
            background-position: center;
            background-size: contain;
            color: #fff;
            font-size: 4rem;
            flex-direction: column;
            justify-content: flex-end;
            border: 7px solid #fff;
            border-width: 0px 15px;
        }

        .brand-aboutus {
            height: 100%;
            text-align: center;
            position: relative;
        }

        .brand-img p {
            font-size: 2.5rem;
            margin-bottom: 0;
            line-height: 25px;
            position: absolute;
            bottom: 27%;
            left: 47%;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        .brand-img h3 {
            color: #fff;
            font-size: 9rem;
            position: absolute;
            bottom: 2%;
            left: 35%;
        }

        .brand-img i {
            position: absolute;
            bottom: 38%;
            left: 48%;
        }

        .headings-all {
            font-family: 'Annabelle';
            font-size: 5rem;
            font-weight: bold;
            color: #fff;
            text-shadow: 2px 2px 2px #69301e;
        }

        .text-section .headings-all {
            margin-bottom: 38px;
        }

        .carousel-item .row .col-lg-4 img {
            height: 100%;
            width: 100%;
            margin: 0 4px 0 4px;
        }

        .sections .row {
            height: 69vh;
            margin: 10vh 0 10vh 0;
        }

        .headings-row {
            height: 79vh;
            margin: 0vh 0 5vh 0;
        }

        .headings-row img {
            object-fit: cover;

        }

        .sections.radiusRight.headings-row img,
        .radiusRight img {
            border-radius: 0 155px 0 0;
            object-fit: cover;
        }

        .sections.radiusLeft.headings-row img,
        .radiusLeft img {
            border-radius: 155px 0 0 0;
            object-fit: cover;
        }

        .sections .row .col-lg-6 {
            gap: 0px;
            height: 114%;
        }

        .sections img {
            height: 100%;
        }

        .mainSection-services .sections {
            height: 79 vh;
        }

        .mainSection-services .section-4,
        .mainSection-services .section-3 {
            margin-top: 155px;
        }

        .sub-header h3 {
            color: #69301e;
        }

        .text-section {
            padding: 4.2rem;
            font-size: 1rem;
            line-height: 34px;
        }

        .text-section p,
        .text-section a {
            font-family: 'LeMondeLivre Demi Small Caps';
            font-weight: 100;
            color: black;
        }

        /* card css  */
        .sections.cards {
            /* card ke width 9rem padding say kam ke hay filhal */
            padding: 0rem 9rem 0 9rem;
            background: none;
        }

        .sections.cards .container {
            height: 100%;
        }

        .sections.cards {
            height: 100%;
            margin: 0px;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        .sections.cards .col-lg-4 {
            height: 100%;
            width: 100%;
        }

        .sections.cards .row img {
            height: 100%;
            width: 100%;
        }

        .cards a {
            display: flex;
            justify-content: space-between;
            margin: 10px;
            color: #9e6a5a;
            font-weight: 500;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        .cards p span {
            font-weight: 700;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        /* footer css */
        Footer {
            background: #f4f4f4;
            padding: 69px 0 15px 0;

        }

        footer .col-lg-6 {
            margin: auto;
            text-align: center;
        }

        Footer h4 {
            color: #69301e;
            font-size: 2rem;
            margin-bottom: 29px;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        footer p {
            color: #9b6756;
            font-size: 1.1rem;
            margin-bottom: 22px;
            line-height: 30px;
            font-family: 'LeMondeLivre Demi Small Caps';
            width: 90%;
        }

        footer p.terms a {
            color: #69301e;

            font-weight: 500;
        }

        footer p.icons {

            margin-bottom: 35px;
        }

        footer form {
            display: flex;
            justify-content: center;
            padding-bottom: 25px;
            width: 60%;
            margin: auto;
        }

        footer form input {
            padding: 12px;
            border: 1px solid #1a1a1a;
            width: 80%;
        }

        footer form input[type="submit"] {
            background: #1a1a1a;
            color: #fff;
            width: 20%;
            cursor: pointer;
        }

        footer form input[type="submit"]:hover {
            background-color: #9b6756;

            transition: all 0.3s ease;
            border: 1px solid #9b6756;
        }

        .icons i:hover,
        .terms a:hover {
            color: #9b6756;
            transform: translateY(-8px);
            transition: transform 0.8s ease;
        }

        footer p.icons i {
            color: #1a1a1a;
            margin-right: 9px;
        }

        p.copyright {
            color: #9b6756;
            font-size: 1rem;
            padding: 17px 0 17px 0;
            text-align: center;
            margin-bottom: 0px;
        }

        /* contact us css */
        .section-2.contactus {
            padding: 2rem 0;
        }

        .contactus.mainform {
            height: 71vh;
            width: 55vw;
            border: 1px solid #69301e;
            margin: 40px auto;
            background: none;
            display: flex;
            flex-direction: column;
            gap: 10px;
            border-radius: 0% 200px 0% 200px;
        }

        .contactus.mainform .row {
            margin: 0 auto;
        }

        .contactus.mainform .col-12 {
            background: none;
            padding-left:4rem;
            justify-content: flex-start;
        }

        .contactus .col-12 input {
            width: 100%;
            border: 3px solid lightgray;
            border-width: 0 0 3px 0;
            padding: 18px 8px;
            margin-bottom: 5px;
        }

        .contactus.mainform .twoInput {
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }

        .contactus input[type="submit"] {
            width: 20%;
            background: #fcfcfc;
            color: #9b6756;
            position: relative;
            border: 2px solid #9b6756;
            border-width: 2px 2px 0 0;
            display:inline-block;
            margin-top: 40px;
            margin-left: 40%;
            text-transform: uppercase;
            cursor: pointer;
        }

        /* .contactus .mainform input[name="message"]{height:120px;} */
        .subBtn::before {
            content: '';
            height: 2px;
            width: 15%;
            margin-left: 25px;
            background-color: #9b6756;
            position: absolute;
            left: 9%;
            bottom: 8%;
        }

        .contactus.mainform input[type="submit"]::after {
            content: '';
            height: 155px;
            width: 155px;
            border: 3px solid #9b6756;
            border-width: 0 0 3px 3px;
            position: absolute;
            left: 0;
            bottom: 0;
        }

        .getInTouch .row .col-lg-6 {
            display: flex;
            flex-direction: column;
        }

        .getInTouch {
            margin: 0 0 6rem 0;
        }

        .getInTouch .touch {
            margin: 1rem 0;
        }

        .contactus .row,
        .touch .row {
            width: 60vw;
            background: none;
            margin: 80px auto;
        }

        .getInTouch .col-lg-6 {
            margin: auto;
            text-align: center;
        }

        .getInTouch .col-lg-6 h4,
        .formHeading h4 {
            font-size: 2.8rem;
            word-spacing: 4px;
            text-transform: capitalize;
            font-style: italic;
            color: black;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        .getInTouch .col-lg-6 h4 span,
        .formHeading h4 span {
            color: #69301e;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        .getInTouch .col-lg-6 p,
        .formHeading p {
            color: #00000073;
            font-size: 0.95rem;
            line-height: 25px;
            font-family: 'LeMondeLivre Demi Small Caps';
        }

        .formHeading h4,
        .formHeading p {
            width: 85%;
            text-align: center;
            margin: 10px auto;
        }

        .formHeading h4 {
            font-size: 2.1rem
        }

        .formHeading p {
            margin-bottom: 30px;
        }

        /* .callEmail{gap:2px} */


        .touch .row {
            justify-content: center;
            margin: 17px auto;
            text-align: center;
        }

        .content {
            background: #f2f3f4;
            padding: 3rem;
            border-radius: 20px 0;
            border: 2px solid #fff;
        }

        .content i {
            font-size: 2.8rem;
            display: block;
            padding-bottom: 12px;
        }

        .content i,
        .content span {
            color: #69301e;
        }

        .content span {
            font-size: 1.3rem;
            font-weight: 500;
        }

        .content.callUs {
            border-radius: 100px 0 0 0;
            width: 100%;
        }

        .content.email {
            border-radius: 0 0 100px 0;
            width: 100%;
        }

        .content:hover {
            border: 2px solid #69301e;
        }

        section.sections.cards.section-5 .row {
            padding-bottom: 7vh;
        }

        /* crousal aeros */
        .prev_arrow {
            position: relative;
            right: 70px;
            top: 234px;
            background-color: #fff;
            color: #69301e;
            height: 150px;
            width: 150px;
            text-align: center;
            padding: 8px 17px;
            border-radius: 50%;
            font-size: 1.5rem;
            border: 1px solid #69301e;
        }

        .next_arrow {
            position: relative;
            left: 100%;
            bottom: 234px;
            background-color: #fff;
            color: #69301e;
            height: 50px;
            width: 50px;
            text-align: center;
            padding: 8px 17px;
            font-size: 1.5rem;
            border-radius: 50%;
            border: 1px solid #69301e;

        }

        .next_arrow:hover,
        .prev_arrow:hover {
            background-color: #69301e;
            color: #fff;

        }

        .cardsCrousal .row.slick-initialized.slick-slider {
            padding: 0px;
            height: 100%;
            margin: 0px;
        }

        .fa-circle-play {
            cursor: pointer;
        }

        .fa-circle-play:hover {
            color: #9b6756;
            transform: translateY(-8px);
            transition: all 300ms ease-in-out;
        }

        .text-section p {
            font-family: 'LeMondeLivre Demi Small Caps';
            font-weight: 100;
            color: #00000073;
        }

        .text-section a {
            color: #9b6756
        }

        .text-section a::after {
            content: '';
            height: 2px;
            width: 15%;
            margin-left: 25px;
            background-color: #9b6756;
            position: absolute;
            left: 9%;
            bottom: 8%;
        }
    </style>


</head>

<body>
    <!-- nav start  -->
    <section>
        <div class="container-fluid">
            <div class="sub-header">
                <div class="row">
                    <div class="col-12">
                        <p><a href="#">free shipping on u.s orders over &dollar;50!</a></p>
                    </div>
                </div>
            </div>
        </div>

        <nav>
            <div class="container">
                <div class="row">
                    <div class="col-12 col-lg-4">
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="services.php">services</a></li>
                            <li><a href="#">shop</a></li>
                            <li><a href="index.php">about</a></li>
                            <li><a href="contactUs.php">contact us</a></li>
                        </ul>
                    </div>
                    <div class="col-12 col-lg-4">
                        <div id="brand-name">
                            <a href="#">
                                <h3>Eve <span>2</span> Down</h3>
                                <p>Boutique</p>
                            </a>
                        </div>
                    </div>
                    <div class="col-12 col-lg-4">
                        <ul class="search">
                            <li><a href="#"><i class="fa-solid fa-magnifying-glass"></i>search</a></li>
                            <li><a href="#">Account</a></li>
                            <li><a href="#"><i class="fa-solid fa-basket-shopping"></i>
                                    <!-- <i class="fa-light fa-basket-shopping"></i> -->
                                    cart</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </section>
