<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/slick.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script> -->
<script src="js/app.js"></script>
<script>
     $('.cardsCrousal .row').slick({
  infinite: true,
  slidesToShow: 3,
  slidesToScroll: 3,
  prevArrow:'<span class="prev_arrow"> <i class="fa-solid fa-angle-left"></i> </span>',
  nextArrow:'<span class="next_arrow"> <i class="fa-solid fa-angle-right"></i> </span>'
});
</script>