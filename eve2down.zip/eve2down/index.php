<!-- Header -->
<?php
$title = "Abous Us";
include 'include/header.php';
?>

<!-- banner section start -->
<section class="banner">
  <div class="container">
    <div>
      <p>Eve 2 Down botique</p>
      <h3 class="headings-all">About Us</h3>
    </div>
  </div>
</section>

<!-- section-1 -->
<div class="sections radiusRight headings-row">
  <div class="container">
    <div class="row">
      <div class="col-12 col-lg-6">
        <img src="images/heading.png" alt="brandImage" class="imgFluid">
      </div>
      <div class="col-12 col-lg-6">
        <div class="text-section">
          <h3 class="headings-all">Heading <br>Goes Here</h3>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem.
          </p>
        </div>
      </div>
    </div>


  </div>
</div>

<!-- section-2 -->
<section class="sections brand-aboutus">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="brand-img">
          <i class="fa-regular fa-circle-play"></i>
          <p>About Our</p>
          <h3 class="headings-all">Brand</h3>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- section-3 -->
<section class="sections headings-row radiusLeft">
  <div class="container">
    <div class="row">
      <div class="col-12 col-lg-6">
        <div class="text-section">
          <h3 class="headings-all">Heading <br>Goes Here</h3>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem.Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem.
          </p>
        </div>
      </div>
      <div class="col-12 col-lg-6">
        <img src="images/heading.png" alt="brandImage" class="imgFluid">
      </div>
    </div>
  </div>
</section>

<!-- Carousel -->
<section class="sections cards section-5 cardsCrousal">
  <div class="container ">
    <div class="row">
      <div class="col-12 col-lg-4">
        <a href="#">
          <img src="images/slider-img.png" alt="slider-image1" class="imgFluid">
        </a>
        <a href="#">
          Lorem ipsum dolor sit amet <span>&dollar;47.00</span>
        </a>
      </div>
      <div class="col-12 col-lg-4">
        <a href="#">
          <img src="images/slider-img2.png" alt="slider-image2" class="imgFluid">
        </a>
        <a href="#">
          Lorem ipsum dolor sit amet <span>&dollar;47.00</span>
        </a>
      </div>
      <div class="col-12 col-lg-4">
        <a href="#">
          <img src="images/slider-img3.png" alt="slider-image3" class="imgFluid">
        </a>
        <a href="#">
          Lorem ipsum dolor sit amet <span>&dollar;47.00</span>
        </a>
      </div>
      <div class="col-12 col-lg-4">
        <a href="#">
          <img src="images/slider-img.png" alt="slider-image1" class="imgFluid">
        </a>
        <a href="#">
          Lorem ipsum dolor sit amet <span>&dollar;47.00</span>

        </a>
      </div>
      <div class="col-12 col-lg-4">
        <a href="#">
          <img src="images/slider-img2.png" alt="slider-image2" class="imgFluid">
        </a>
        <a href="#">
          Lorem ipsum dolor sit amet <span>&dollar;47.00</span>
        </a>
      </div>
      <div class="col-12 col-lg-4">
        <a href="#">
          <img src="images/slider-img3.png" alt="slider-image3" class="imgFluid">
        </a>
        <a href="#">
          Lorem ipsum dolor sit amet <span>&dollar;47.00</span>
        </a>
      </div>
      <div class="col-12 col-lg-4">
        <a href="#">
          <img src="images/slider-img.png" alt="slider-image1" class="imgFluid">
        </a>
        <a href="#">
          Lorem ipsum dolor sit amet <span>&dollar;47.00</span>

        </a>
      </div>
      <div class="col-12 col-lg-4">
        <a href="#">
          <img src="images/slider-img2.png" alt="slider-image2" class="imgFluid">
        </a>
        <a href="#">
          Lorem ipsum dolor sit amet <span>&dollar;47.00</span>
        </a>
      </div>
      <div class="col-12 col-lg-4">
        <a href="#">
          <img src="images/slider-img3.png" alt="slider-image3" class="imgFluid">
        </a>
        <a href="#">
          Lorem ipsum dolor sit amet <span>&dollar;47.00</span>
        </a>
      </div>
    </div>
  </div>
</section>

<!-- Footer -->
<?php include 'include/footer.php'; ?>