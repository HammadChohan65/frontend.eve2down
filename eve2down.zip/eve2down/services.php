<!-- Header -->
<?php
$title = "Services";
include 'include/header.php';
?>

<!-- banner section start -->
<section class="banner section-1">
    <div class="container">
        <div>
            <p>Eve 2 Down botique</p>
            <h3 class="headings-all">Services</h3>
        </div>
    </div>
</section>

<!-- post section start -->
<section class="mainSection-services">
    <section class="sections section-2 radiusRight">
        <div class="container">
            <div class="row">

                <div class="col-12 col-lg-6">
                    <img src="images/service1.png" alt="brandImage" class="imgFluid service1">
                </div>
                <div class="col-12 col-lg-6">
                    <div class="text-section">
                        <h3 class="headings-all">Heading <br>Goes Here</h3>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem.
                        </p>
                        <p class="viewDetails"><a href="#">View details</a></p>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <section class="sections section-3 radiusLeft">
        <div class="container">
            <div class="row">

                <div class="col-12 col-lg-6">
                    <div class="text-section">
                        <h3 class="headings-all">Heading <br>Goes Here</h3>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem.Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem.
                        </p>
                        <p class="viewDetails"><a href="#">View details</a></p>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <img src="images/service2.png" alt="brandImage" class="imgFluid service2">
                </div>
            </div>
        </div>
    </section>
    <section class="sections section-4 radiusRight">
        <div class="container">
            <div class="row">

                <div class="col-12 col-lg-6">
                    <img src="images/service3.png" alt="brandImage" class="imgFluid service3">
                </div>
                <div class="col-12 col-lg-6">
                    <div class="text-section">
                        <h3 class="headings-all">Heading <br>Goes Here</h3>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem. Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos dolore reiciendis totam alias laudantium corrupti voluptate dolores vero dicta, aspernatur impedit, enim earum cumque esse aut, qui hic a exercitationem.
                        </p>
                        <p class="viewDetails"><a href="#">View details</a></p>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- form section start -->
    <section class="section-2 contactus">
        <div class="container">
            <div class="sections contactus mainform">
                <div class="row">

                    <div class="col-12">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <div class="formHeading">
                                <h4>Have any <span>Query?</span></h4>
                                <p>Fill out the form bellow and we will get back to you as soon a possible!</p>
                                <div class="twoInput">
                                    <input type="text" name="name" placeholder="Name">
                                    <input type="number" name="phone" placeholder="Phone Number">
                                </div>
                                <input type="email" name="email" placeholder="Email Address">
                                <input type="text" name="subject" placeholder="Subject">
                                <input type="text" name="message" placeholder="Message">
                                <input type="submit" value="Submit">
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'include/footer.php'; ?>